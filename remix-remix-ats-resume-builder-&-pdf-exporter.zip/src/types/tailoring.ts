export type TailoringIntensity = "balanced" | "targeted" | "concise";

export interface TailoredSkillGroup {
  category: string;
  items: string[];
}

export interface TailoredExperienceItem {
  id: string;
  role: string;
  intro: string;
  bullets: string[];
  tags: string[];
}

export interface TailoredProjectItem {
  id: string;
  title: string;
  description: string;
}

export interface TailoredResumeContent {
  headlineRole: string;
  headlineSubtitle: string;
  summary: string;
  skillGroups: TailoredSkillGroup[];
  experiences: TailoredExperienceItem[];
  projects: TailoredProjectItem[];
}

export interface DocFileItem {
  folder: string;
  filename: string;
  content: string;
  sizeBytes: number;
  updatedAt: string;
}

export interface AtsScoreBreakdown {
  keywordMatch: number;
  experienceRelevance: number;
  impactAndMetrics: number;
  atsStructureReadability: number;
}

export interface AtsMissingKeyword {
  keyword: string;
  importance: "high" | "medium";
  inDocs: boolean;
  whereToAddFa: string;
}

export interface AtsSuggestedAddition {
  id: string;
  category: "skill" | "bullet" | "project" | "summary";
  titleFa: string;
  reasonFa: string;
  targetSectionId?: string;
  englishContent: string;
  verifiedFromDocs: boolean;
}

export interface AtsOptimizationItem {
  priority: "high" | "medium" | "low";
  actionFa: string;
  expectedImpactFa: string;
}

export interface AtsAnalysisResult {
  overallScore: number;
  projectedScoreAfterOptimization: number;
  scoreBreakdown: AtsScoreBreakdown;
  detectedCompany: string;
  detectedRole: string;
  executiveVerdictFa: string;
  matchedKeywords: string[];
  missingKeywords: AtsMissingKeyword[];
  suggestedAdditions: AtsSuggestedAddition[];
  optimizationChecklistFa: AtsOptimizationItem[];
  docsUsed: string[];
  analyzedAt: number;
}

export interface TailoredDraft {
  id: string;
  createdAt: number;
  jobDescription: string;
  targetCompany: string;
  targetRole: string;
  intensity: TailoringIntensity;
  matchedKeywords: string[];
  missingOrGapKeywords: string[];
  tailoringRationale: string;
  docsUsed?: string[];
  atsScoreBefore?: number;
  atsScoreAfter?: number;
  content: TailoredResumeContent;
}

export const MASTER_RESUME_CONTENT: TailoredResumeContent = {
  headlineRole: "Technical Product Manager",
  headlineSubtitle: "Ex-Frontend Engineer | Product Discovery & Dev Handoff",
  summary:
    'Technical Product Manager specializing in **Product Discovery & Dev Handoff** with a solid software engineering foundation in modern frontend architecture. Led the **Delband** Medicine 3.0 digital health platform (wearables & AI ecosystem) from 0-to-1 startup to an accredited **Knowledge-Based Enterprise**, securing **two institutional funding rounds**, **Presidential Innovation Fund** backing, and strategic acquisition by **Hamrahe Aval (MCI)**. Expert in bridging engineering squads, clinical advisors, and C-suite stakeholders using **Jobs-to-be-Done (JTBD)**, **Root Cause Analysis**, and metric-driven execution to scale enterprise B2B offerings (e.g., **Mobarakeh Steel Group**).',
  skillGroups: [
    {
      category: "Product Strategy",
      items: [
        "Product Discovery",
        "AI Rapid Prototyping",
        "Startup Building",
        "Product Building",
        "Roadmap Planning",
        "OKRs",
        "PRD Writing",
        "Agile/Scrum",
        "User Research",
        "Jobs-to-be-Done (JTBD)",
        "Lean Validation (Wizard of Oz)",
        "GTM Strategy",
        "Prioritization",
        "Growth Hacking",
        "Stakeholder Management",
      ],
    },
    {
      category: "Technical Architecture",
      items: [
        "Custom AI Agent & Skills",
        "TypeScript",
        "React",
        "Angular",
        "RESTful APIs",
        "SQL",
        "Markdown Specs",
        "Prompt Engineering",
        "JavaScript",
        "Tailwind CSS",
        "Bootstrap",
        "CI/CD",
        "RxJS",
        "Service Workers",
        "Unit Testing",
      ],
    },
    {
      category: "Analytics & Business",
      items: [
        "Conversion Funnel Optimization",
        "Customer Acquisition Cost (CAC) Reduction",
        "Internal Rate of Return (IRR) Modeling",
        "A/B Testing",
        "Google Analytics 4",
        "Microsoft Clarity",
      ],
    },
    {
      category: "Tools & Platforms",
      items: [
        "Jira",
        "Figma",
        "Notion",
        "Azure DevOps",
        "Git",
        "CI/CD",
        "Swagger",
        "GitLab",
        "Postman",
      ],
    },
  ],
  experiences: [
    {
      id: "tums",
      role: "Technology & Product Advisor | Mentor Bootcamp",
      intro:
        "Bridging clinical challenges and multidisciplinary tech solutions; mentor in **Iran's first clinical innovation bootcamp**",
      bullets: [
        "**Product Facilitation & Problem-Solving —** Applied **Design Thinking** and **JTBD** frameworks to help clinical staff and engineers discover **problem–solution fit** and build usable digital health ecosystems.",
        "**Rapid Prototyping —** Trained non-technical founders and developers in advanced prompt engineering and rapid prototyping (**Vibe Coding**), enabling a working MVP within a **6-week** window.",
        "**Growth & Fundraising Readiness —** Mentored a cohort of **6 early-stage teams** through a 6-week accelerator to Demo Day; advised on growth strategy and investor pitch structure, guiding **2 teams** into active operation and **fundraising readiness**.",
      ],
      tags: ["Design Thinking", "JTBD", "Prompt Engineering", "Vibe Coding", "Health-Tech", "Fundraising"],
    },
    {
      id: "mci",
      role: "Technical Product Manager",
      intro:
        "Led the delivery of the **first native Med 3.0 digital health** service in Iran by aligning business strategy, user value, and economic impact, and orchestrating cross-functional product, engineering, and stakeholder teams.",
      bullets: [
        "**Lean Assumption Validation —** Rapidly validated a new workout-mode feature using the **Wizard of Oz** technique without tying up engineering resources; flagged and killed a feature with a poor trade-off saving roughly **five sprints**, cutting GTM risk.",
        '**Process-Driven Product Development —** Shifted the development paradigm from person-dependent to process-dependent to remove key-person risk; redesigned the OKR system around a "value window" principle, driving sprint completion **20% ahead of initial estimates** without adding headcount.',
        '**Freemium Conversion Funnel Design —** Built a freemium, gamification-based conversion funnel for the "Health Companion" segment; designed an organic path guiding free, **sensor-less users** toward hardware purchase and subscription.',
        "**Organizational Strategic Pivot —** Led a strategic pivot into organizational health services with an enterprise digital health dashboard; opened new GTM channels and won clients including **Mobarakeh Steel**, driving a projected **15% increase in business-plan IRR**.",
        "**Mini-App & Messaging Bot Development —** Launched a native mini-app and bot across three domestic messaging platforms (**Telegram, Bale, Rubika**) with an **AI reporting and coaching assistant**; drove organic acquisition of users without wearable hardware and lowered **CAC**.",
        "**Segmentation Optimization —** Sharpened the split between buyer persona and end user and stopped targeting noisy, low-value cohorts; refocused product resources on higher-return segments and lowered customer acquisition cost (**CAC**).",
        "**Product Vision & Strategy Shift —** Shifted the product from raw health-data display to preventive guidance by designing three specialized modules (women's health, workout modes, calorie counting) on a **freemium model** to boost daily app usability and premium conversions (currently in **pilot** acquisition).",
      ],
      tags: ["React", "Product Strategy", "Product Discovery", "GTM", "OKR", "Agile/Scrum", "Prototyping"],
    },
    {
      id: "uxcel",
      role: "Product Management Mentor",
      intro:
        "Member of the Uxcel mentoring team — ranked among the **top 10 product management mentors** on an interactive learning platform serving **500,000+ professionals in 150+ countries** (including Microsoft, IBM, Samsung, and Dropbox).",
      bullets: [
        "**Mentoring & Professional Development —** Coached product management professionals worldwide through regular reviews of **170 real projects** and structured feedback, focused on developing decision-making and execution skills.",
        "**Content Team & Mentor Network Coordination —** Coordinated with Uxcel's content team and international mentor network to design and publish specialized training, ensuring quality consistency across a distributed team.",
      ],
      tags: ["Product Leadership", "Mentorship", "UX Strategy", "Product Team Upskilling", "Coaching"],
    },
    {
      id: "ofoq",
      role: "Frontend Developer",
      intro:
        "Front-end developer with strong product mindset, collaborating closely with **product, SEO, and marketing teams** to deliver high-performance, scalable web experiences while developing stakeholder empathy.",
      bullets: [
        "**Website Update & Redesign —** Rebuilt PLP and PDP pages using Angular 17 with **SSR**, improving performance and SEO; implemented **Bootstrap + Tailwind CSS** for a scalable UI.",
        "**Venus Project —** Built MVPs for employee check-in/out, leave management, and internal dashboards using Angular 14; optimized **cross-platform geolocation**.",
        "**Job Board & Resume Panel —** Developed and deployed a standalone subdomain for HR to manage job listings and applicant workflows with custom pipeline tracking.",
        "**Marketing Dashboard —** Delivered real-time KPI, SEO, and behavior dashboards using **Google Analytics, Clarity, and Looker Studio**, supporting marketing decisions.",
      ],
      tags: ["Angular", "TypeScript", "RxJs", "Sass", "Angular Material", "Bootstrap", "UI/UX", "OOP"],
    },
  ],
  projects: [
    {
      id: "rokhnama",
      title: "Rokhnama — Founder & Product Builder",
      description:
        "Built a lightweight **digital storefront & web catalog engine** replacing static PDFs with mobile-first interactive showcases, including a live portal for **K. N. Toosi University of Technology (International Student Affairs)**.",
    },
    {
      id: "biopad",
      title: "BioPad — Founder & Product Builder",
      description:
        "Architected an independent **multi-wearable bodybuilding & digital health product** (Beta) converting raw biometric telemetry into actionable workout and recovery insights, featuring **3D interactive mascots** and AI-assisted feedback loops.",
    },
    {
      id: "indora",
      title: "Indora — Location Intelligence",
      description:
        "Shipped location-intelligence platform driving data decisions. Authored PRDs, mapped user journeys, and executed initial GTM strategies to operationalize raw location data.",
    },
    {
      id: "stakeholder-portal",
      title: "Stakeholder Portal",
      description:
        "Developed web management dashboard integrating **Gantt scheduling, task boards, and OKR tracking**, centralizing progress to provide transparency for leadership.",
    },
    {
      id: "eldercare",
      title: "Eldercare Coordination Program",
      description:
        'Led interdisciplinary clinical team through agile discovery. Defined "trusted caregiver" criteria and capped scope to a live digital pilot, prioritizing readmission reduction.',
    },
    {
      id: "mentorship-platform",
      title: "Mentorship Services Platform",
      description:
        "Directed end-to-end product discovery for a mentorship platform. Defined persona-driven workflows and prioritized high-value modules (session management, messaging) through final release.",
    },
  ],
};
