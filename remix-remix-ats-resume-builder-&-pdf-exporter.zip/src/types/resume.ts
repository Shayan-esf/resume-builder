export interface ProfileData {
  role: string;
  firstName: string;
  lastName: string;
  subtitle: string;
  about: string;
  quote?: string;
}

export interface ContactData {
  email: string;
  phone: string;
  linkedin: {
    handle: string;
    url: string;
  };
  uxcel: {
    handle: string;
    url: string;
  };
  location: string;
  website: {
    handle: string;
    url: string;
  };
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  companyFa?: string;
  period: string;
  location: string;
  intro?: string;
  bullets: string[];
  tags: string[];
}

export interface EducationItem {
  id: string;
  school: string;
  degree: string;
  period: string;
}

export interface ProjectItem {
  id: string;
  title: string;
  description: string;
  metric?: string;
  url?: string;
}

export interface ResumeData {
  profile: ProfileData;
  contact: ContactData;
  skills: string[];
  experiences: ExperienceItem[];
  education: EducationItem[];
  projects: ProjectItem[];
}

export const DEFAULT_RESUME_DATA: ResumeData = {
  profile: {
    role: "Product Manager",
    firstName: "Shayan",
    lastName: "Esfahanizadeh",
    subtitle: "Specialized in Discovery & Dev Handoff | Ex-Frontend",
    about: `As a Product Manager with a front-end engineering background, I specialize in end-to-end AI-driven products. Utilizing Product Discovery, Root Cause Analysis, and the JTBD framework, I translate complex problems into scalable solutions. I led the Delband digital health platform (Medicine 3.0 wearable ecosystem) from an independent startup to a recognized "Knowledge-Based" company, securing two funding rounds and a strategic acquisition by MCI. I scaled B2B health services to major enterprises including Mobarakeh Steel Group, secured Presidential Innovation Fund backing, and won the top award at the 6th International Digital Health Congress.`,
    quote: "“The best way to predict the future is to create it.” - Peter Drucker",
  },
  contact: {
    email: "esfahanizadeh81@gmail.com",
    phone: "+98 933 300 7274",
    linkedin: {
      handle: "@shayan-esf",
      url: "https://www.linkedin.com/in/shayan-esf/",
    },
    uxcel: {
      handle: "shayanesf",
      url: "https://app.uxcel.com/ux/shayanesf",
    },
    location: "Tehran, Iran",
    website: {
      handle: "esfahanizadeh.vercel.app",
      url: "https://esfahanizadeh.vercel.app/",
    },
  },
  skills: [
    "Product Strategy",
    "Product Discovery",
    "Root Cause Analysis",
    "Jobs-to-be-Done (JTBD)",
    "PRD & Dev Handoff",
    "AI & Prompt Engineering",
    "Vibe Coding",
    "React & TypeScript",
    "User Research",
    "Agile & Scrum",
  ],
  experiences: [
    {
      id: "ofoq-dade",
      role: "Product Facilitator & Startup Mentor",
      company: "Ofoq Dade",
      companyFa: "افق داده",
      period: "Jan 2024 - Present",
      location: "Tehran, Iran",
      intro: "Bridging clinical challenges and multidisciplinary tech solutions; mentor in Iran's first clinical innovation bootcamp",
      bullets: [
        "Product Facilitation & Problem-Solving — Applied Design Thinking and JTBD frameworks to help clinical staff and engineers discover problem-solution fit and build usable digital health ecosystems.",
        "Rapid Prototyping — Trained non-technical founders and developers in advanced prompt engineering and rapid prototyping (Vibe Coding), enabling a working MVP within a 6-week window.",
        "Growth & Fundraising Readiness — Mentored a cohort of 6 early-stage teams through a 6-week accelerator to Demo Day; advised on growth strategy and investor pitch structure, guiding 2 teams into active operation and fundraising readiness.",
      ],
      tags: ["Mentorship", "Innovation", "JTBD", "Rapid Prototyping"],
    },
    {
      id: "delband",
      role: "Product Manager",
      company: "Delband",
      companyFa: "دلبند",
      period: "Jun 2023 - Present",
      location: "Tehran, Iran",
      intro: "Leading the native digital health ecosystem bridging continuous biometric tracking with AI-driven interventions",
      bullets: [
        "End-to-End Discovery & Handoff — Owned user research, wireframing, PRD specification, and dev handoff across mobile and hardware teams.",
        "Freemium Architecture & Engagement — Shifted the product from raw health-data display to everyday preventive guidance by designing three specialized modules (women's health, workout modes, calorie counting) on a freemium model; boosted daily app usability and opened subscription revenue.",
        "Enterprise Health Dashboard (B2B) — Designed and delivered privacy-preserving organizational dashboards monitoring collective workforce burnout and fatigue, scaling to major clients including Mobarakeh Steel Group.",
        "Strategic Growth & M&A — Positioned product metrics and clinical roadmaps leading to two successful funding rounds and strategic acquisition by MCI.",
      ],
      tags: ["Product Strategy", "Digital Health", "B2B Dashboards", "M&A", "Wearables"],
    },
    {
      id: "uxcel",
      role: "Product Management Mentor",
      company: "Uxcel",
      companyFa: "یواکسل",
      period: "Sep 2022 - Present",
      location: "Remote",
      intro: "Global design & product education platform with over 300,000 active learners worldwide",
      bullets: [
        "Global Project Reviews & Coaching — Coached product management professionals worldwide through regular reviews of 170 real projects and structured feedback, focused on developing decision-making and execution skills.",
        "Content Team & Mentor Network Coordination — Coordinated with Uxcel's content team and international mentor network to design and publish specialized training, ensuring quality consistency across a distributed, multicultural team.",
      ],
      tags: ["Product Leadership", "Mentorship", "UX Strategy"],
    },
    {
      id: "saina-system",
      role: "Frontend Engineer",
      company: "Saina System / Venus Project",
      companyFa: "ساینا سیستم",
      period: "Feb 2021 - May 2023",
      location: "Tehran, Iran",
      intro: "Enterprise ERP and HR workflow management solutions",
      bullets: [
        "Venus Project — Built MVPs for employee check-in/out, leave management, and internal dashboards using Angular 14; optimized cross-platform geolocation.",
        "Job Board & Resume Panel — Developed and deployed a standalone subdomain for HR to manage job listings and applicant workflows. Enabled recruiters to track hiring stages with custom UI and workflow logic.",
        "Marketing Dashboard — Delivered real-time KPI, SEO, and behavior dashboards using Google Analytics, Clarity, and Looker Studio, supporting marketing decisions.",
      ],
      tags: ["Angular", "TypeScript", "Frontend Engineering", "HR Tech"],
    },
  ],
  education: [
    {
      id: "kntu",
      school: "K. N. Toosi University of Technology",
      degree: "Bachelor's degree, Computer Engineering, Computer Software Engineering",
      period: "Jun 2020 - Sep 2025",
    },
  ],
  projects: [
    {
      id: "rokhnama",
      title: "Rokhnama — Founder & Product Builder",
      description:
        "Built a lightweight digital storefront & web catalog engine replacing static PDFs with mobile-first interactive showcases, including a live portal for K. N. Toosi University of Technology (International Student Affairs).",
      metric: "Interactive web catalog",
      url: "rokhnama.vercel.app",
    },
    {
      id: "biopad",
      title: "BioPad — Founder & Product Builder",
      description:
        "Architected an independent multi-wearable bodybuilding & digital health product (Beta) turning biometric telemetry into actionable workout and recovery insights with 3D interactive mascots and AI feedback loops.",
      url: "biopad.vercel.app",
    },
    {
      id: "indora",
      title: "Indora — Location Intelligence",
      description:
        "Shipped location-intelligence platform driving data decisions. Authored PRDs, mapped user journeys, and executed initial GTM strategies.",
      url: "indoora.net",
    },
    {
      id: "stakeholder-portal",
      title: "Stakeholder Portal",
      description:
        "Developed web management dashboard integrating Gantt scheduling, task boards, and OKR tracking, centralizing progress to provide transparency for leadership.",
      url: "investor.delbandcare.com",
    },
  ],
};
